import ssl
import uuid

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .chatbot import find_best_answer
from .config import settings
from .database import (
    fetch_alerts,
    fetch_dashboard_data,
    fetch_questions,
    fetch_suggested_questions,
    fetch_transactions,
    save_confirmed_payment_transaction,
)
from .schemas import (
    ChatRequest,
    ChatResponse,
    DashboardResponse,
    PaymentCaptureRequest,
    PaymentCaptureResponse,
    PaymentOrderResponse,
    PaymentRequest,
)


def _paypal_ssl_context() -> ssl.SSLContext:
    return ssl.create_default_context()


def _paypal_http_error(action: str, response: httpx.Response) -> HTTPException:
    error_code = ""
    try:
        payload = response.json()
        if isinstance(payload, dict):
            error_code = str(payload.get("error") or payload.get("name") or "")
    except Exception:
        error_code = ""

    if error_code == "invalid_client":
        return HTTPException(
            status_code=502,
            detail=(
                "PayPal authentication failed: the Client ID and Client Secret were rejected. "
                "Open the PayPal Developer Dashboard, select Apps & Credentials, switch to Sandbox, "
                "and copy the REST API Client ID and Secret for this app into backend/.env as "
                "PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET. Sandbox credentials only work with "
                "https://api-m.sandbox.paypal.com. Restart the backend after saving .env."
            ),
        )

    return HTTPException(
        status_code=502,
        detail=f"PayPal {action} failed. Check the sandbox app credentials and try again.",
    )


def get_paypal_access_token() -> str | None:
    settings.reload_paypal()
    if not settings.paypal_credentials_configured():
        return None

    response = httpx.post(
        f"{settings.PAYPAL_BASE_URL.rstrip('/')}/v1/oauth2/token",
        data={"grant_type": "client_credentials"},
        auth=(settings.PAYPAL_CLIENT_ID, settings.PAYPAL_CLIENT_SECRET),
        headers={
            "Accept": "application/json",
            "Accept-Language": "en_US",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        timeout=20,
        verify=_paypal_ssl_context(),
    )

    if response.status_code >= 400:
        raise _paypal_http_error("authentication", response)

    token = response.json().get("access_token")
    if not token:
        raise HTTPException(status_code=502, detail="PayPal token response was empty.")

    return token


def create_paypal_checkout_order(amount: float, currency: str, description: str | None) -> dict:
    token = get_paypal_access_token()
    if not token:
        raise HTTPException(
            status_code=500,
            detail=(
                "PayPal client credentials are missing. Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET "
                "in backend/.env using Sandbox REST API values from the PayPal Developer Dashboard."
            ),
        )

    payload = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "amount": {
                    "currency_code": currency.upper(),
                    "value": f"{amount:.2f}",
                },
                "description": description or "Fintech service payment",
            }
        ],
        "application_context": {
            "brand_name": settings.APP_TITLE,
            "user_action": "PAY_NOW",
            "return_url": "http://localhost:5173/payment/success",
            "cancel_url": "http://localhost:5173/payment/cancel",
        },
    }

    response = httpx.post(
        f"{settings.PAYPAL_BASE_URL.rstrip('/')}/v2/checkout/orders",
        json=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        timeout=20,
        verify=_paypal_ssl_context(),
    )

    if response.status_code >= 400:
        raise _paypal_http_error("order creation", response)

    return response.json()


def capture_paypal_order(order_id: str) -> dict:
    token = get_paypal_access_token()
    if not token:
        raise HTTPException(
            status_code=500,
            detail=(
                "PayPal client credentials are missing. Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET "
                "in backend/.env using Sandbox REST API values from the PayPal Developer Dashboard."
            ),
        )

    response = httpx.post(
        f"{settings.PAYPAL_BASE_URL.rstrip('/')}/v2/checkout/orders/{order_id}/capture",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        timeout=20,
        verify=_paypal_ssl_context(),
    )

    if response.status_code >= 400:
        raise _paypal_http_error("capture", response)

    return response.json()


def _extract_paypal_capture_amount(paypal_data: dict) -> float:
    try:
        for purchase_unit in paypal_data.get("purchase_units", []):
            payments = purchase_unit.get("payments", {})
            for capture in payments.get("captures", []):
                amount = capture.get("amount") or {}
                value = amount.get("value")
                if value is not None:
                    return float(value)
    except Exception:
        return 0.0
    return 0.0


def _extract_paypal_capture_currency(paypal_data: dict) -> str:
    try:
        for purchase_unit in paypal_data.get("purchase_units", []):
            payments = purchase_unit.get("payments", {})
            for capture in payments.get("captures", []):
                amount = capture.get("amount") or {}
                currency = amount.get("currency_code")
                if currency:
                    return str(currency).upper()
    except Exception:
        return "USD"
    return "USD"


def _paypal_reporting_permission_message(action: str) -> str:
    return (
        f"PayPal {action} is unavailable. The Sandbox app may not have the required Reporting API permission, "
        "or the report has not refreshed yet. Grant the Reporting API scope in the PayPal Developer Dashboard "
        "and wait a few minutes before retrying. This app does not invent balances or transactions."
    )


def _paypal_money_float(value) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, dict):
        return _paypal_money_float(value.get("value") or value.get("amount") or value.get("total"))
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return 0.0
    return 0.0


def _paypal_reporting_get(endpoint: str, action: str, params: dict | None = None) -> dict:
    token = get_paypal_access_token()
    if not token:
        raise HTTPException(
            status_code=500,
            detail=(
                "PayPal client credentials are missing. Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET "
                "in backend/.env using Sandbox REST API values from the PayPal Developer Dashboard."
            ),
        )

    response = httpx.get(
        f"{settings.PAYPAL_BASE_URL.rstrip('/')}{endpoint}",
        params=params or {},
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
        timeout=20,
        verify=_paypal_ssl_context(),
    )

    if response.status_code == 403:
        raise HTTPException(status_code=403, detail=_paypal_reporting_permission_message(action))

    if response.status_code >= 400:
        raise _paypal_http_error(action, response)

    try:
        payload = response.json()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"PayPal {action} returned an invalid response.") from exc

    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail=f"PayPal {action} returned an unexpected payload.")

    return payload


def fetch_paypal_account_balance() -> dict:
    payload = _paypal_reporting_get(
        "/v1/reporting/balances",
        "balance report",
        params={"page_size": 100},
    )

    balances = payload.get("balances") or payload.get("items") or payload.get("records") or []
    if not isinstance(balances, list):
        balances = []

    normalized = []
    for entry in balances:
        if not isinstance(entry, dict):
            continue
        total = entry.get("total_balance") or entry.get("totalBalance") or entry.get("total") or {}
        available = entry.get("available_balance") or entry.get("availableBalance") or entry.get("available") or {}
        currency = (
            entry.get("currency")
            or (total.get("currency") if isinstance(total, dict) else None)
            or (available.get("currency") if isinstance(available, dict) else None)
            or entry.get("currency_code")
            or "USD"
        )
        normalized.append(
            {
                "currency": str(currency).upper(),
                "available_balance": _paypal_money_float(available),
                "total_balance": _paypal_money_float(total),
                "last_refresh_time": entry.get("last_refresh_time") or entry.get("last_refresh") or entry.get("last_updated") or entry.get("as_of") or None,
                "is_primary": bool(entry.get("primary") or entry.get("is_primary")),
            }
        )

    return {
        "status": "ok",
        "balances": normalized,
        "message": "PayPal Sandbox balance data loaded from the Reporting API.",
        "reporting_delay_notice": "Balances may take several minutes to appear after a payment is approved.",
    }


def fetch_paypal_transaction_history(limit: int = 10) -> dict:
    payload = _paypal_reporting_get(
        "/v1/reporting/transactions",
        "transaction report",
        params={"page_size": limit, "sort_by": "transaction_date", "sort_order": "DESC"},
    )

    transactions = payload.get("transaction_details") or payload.get("transactions") or payload.get("items") or payload.get("records") or []
    if not isinstance(transactions, list):
        transactions = []

    normalized = []
    for entry in transactions:
        if not isinstance(entry, dict):
            continue
        transaction_info = entry.get("transaction_info") if isinstance(entry.get("transaction_info"), dict) else entry
        if not isinstance(transaction_info, dict):
            continue

        amount = transaction_info.get("transaction_amount") or transaction_info.get("amount") or {}
        amount_value = amount.get("value") if isinstance(amount, dict) else amount
        parsed_amount = _paypal_money_float(amount_value)
        currency = (
            (amount.get("currency_code") if isinstance(amount, dict) else None)
            or transaction_info.get("currency_code")
            or "USD"
        )
        tx_id = (
            transaction_info.get("transaction_id")
            or transaction_info.get("id")
            or entry.get("id")
            or "N/A"
        )
        transaction_date = (
            transaction_info.get("transaction_initiation_date")
            or transaction_info.get("transaction_date")
            or transaction_info.get("transaction_updated_date")
            or transaction_info.get("time_posted")
            or None
        )
        status = transaction_info.get("transaction_status") or transaction_info.get("status") or "UNKNOWN"
        direction = "debit" if parsed_amount < 0 else "credit"

        normalized.append(
            {
                "transaction_id": str(tx_id),
                "transaction_date": transaction_date,
                "amount": parsed_amount,
                "currency": str(currency).upper(),
                "status": str(status),
                "direction": direction,
            }
        )

    return {
        "status": "ok",
        "transactions": normalized,
        "message": "PayPal Sandbox transaction history loaded from the Reporting API.",
        "reporting_delay_notice": "Reporting data can lag behind a payment approval by a few minutes.",
    }


app = FastAPI(title=settings.APP_TITLE, version=settings.APP_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_origin_regex=settings.CORS_ORIGIN_REGEX,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {"status": "ok", "service": settings.APP_TITLE}


@app.get("/questions")
def get_questions():
    try:
        rows = fetch_suggested_questions(limit=10)
        return {"questions": rows}
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=500, detail=f"Database error: {str(exc)}") from exc


@app.post("/chat", response_model=ChatResponse)
def chat_with_bot(payload: ChatRequest):
    question = payload.question.strip()

    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty.")

    try:
        result = find_best_answer(question)
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=500, detail=f"Database error: {str(exc)}") from exc

    if result is None:
        return ChatResponse(
            question=question,
            answer=(
                "I could not find a strong match in the current knowledge base. "
                "This chatbot is an educational prototype and is not an official Indian Overseas Bank service. "
                "Please check the official IOB website for the latest policy, eligibility, rates, and documents."
            ),
            category="unmatched",
            source_url="https://www.iob.bank.in/en/",
            confidence=0,
            match_found=False,
        )

    return ChatResponse(
        question=question,
        answer=result["answer"],
        category=result["category"],
        source_url=result.get("source_url"),
        confidence=result.get("confidence", 0),
        match_found=True,
        chart=result.get("chart"),
    )


@app.get("/dashboard", response_model=DashboardResponse)
def get_dashboard_data():
    data = fetch_dashboard_data()
    return data


@app.get("/transactions")
def list_transactions():
    return {"transactions": fetch_transactions()}


@app.get("/alerts")
def list_alerts():
    return {"alerts": fetch_alerts()}


@app.get("/paypal/balance")
def get_paypal_balance_report():
    try:
        return fetch_paypal_account_balance()
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover - defensive path
        raise HTTPException(
            status_code=502,
            detail=(
                "PayPal Sandbox balance retrieval failed. The Reporting API may require additional permissions "
                "or the report may still be refreshing."
            ),
        ) from exc


@app.get("/paypal/transactions")
def get_paypal_transactions_report():
    try:
        return fetch_paypal_transaction_history(limit=10)
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover - defensive path
        raise HTTPException(
            status_code=502,
            detail=(
                "PayPal Sandbox transaction history retrieval failed. The Reporting API may require additional "
                "permissions or the report may still be refreshing."
            ),
        ) from exc


@app.post("/payment/create-order", response_model=PaymentOrderResponse)
def create_payment_order(payload: PaymentRequest):
    try:
        amount = float(payload.amount)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail="Payment amount must be a valid number.") from exc

    if amount <= 0:
        raise HTTPException(status_code=400, detail="Payment amount must be greater than zero.")

    order_id = f"demo-order-{uuid.uuid4().hex[:12]}"
    currency = (payload.currency or "USD").upper()
    settings.reload_paypal()

    if not settings.paypal_credentials_configured():
        return PaymentOrderResponse(
            status="demo",
            order_id=order_id,
            amount=f"{amount:.2f}",
            currency=currency,
            mode="demo",
            message="Payment order created in demo mode. This is not a live PayPal Sandbox payment.",
            approval_url=None,
        )

    if currency == "INR":
        return PaymentOrderResponse(
            status="demo",
            order_id=order_id,
            amount=f"{amount:.2f}",
            currency="INR",
            mode="demo",
            message=(
                f"Payment order created for ₹{amount:.2f} in demo mode. "
                "PayPal Sandbox REST checkout supports USD/EUR; INR is kept in demo mode."
            ),
            approval_url=None,
        )

    try:
        paypal_data = create_paypal_checkout_order(amount, currency, payload.description)
        approval_url = next(
            (link["href"] for link in paypal_data.get("links", []) if link.get("rel") == "approve"),
            None,
        )

        return PaymentOrderResponse(
            status=paypal_data.get("status", "created").lower(),
            order_id=paypal_data.get("id", order_id),
            amount=f"{amount:.2f}",
            currency=currency,
            mode=settings.PAYPAL_MODE,
            message="PayPal Sandbox order created successfully.",
            approval_url=approval_url,
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=(
                "PayPal order creation failed. The transaction was not completed and cannot be marked successful. "
                "Check the Sandbox credentials and verify the App ID and secret in backend/.env."
            ),
        ) from exc


@app.post("/payment/capture-order", response_model=PaymentCaptureResponse)
def capture_payment_order(payload: PaymentCaptureRequest):
    if not payload.order_id:
        raise HTTPException(status_code=400, detail="Order ID is required.")

    settings.reload_paypal()
    if not settings.paypal_credentials_configured() or payload.order_id.startswith("demo-"):
        return PaymentCaptureResponse(
            status="demo",
            order_id=payload.order_id,
            captured=False,
            message="Demo capture is not a real PayPal Sandbox transaction. No live payment was captured.",
        )

    try:
        paypal_data = capture_paypal_order(payload.order_id)
        captured = paypal_data.get("status", "").upper() == "COMPLETED"
        if not captured:
            return PaymentCaptureResponse(
                status="failed",
                order_id=payload.order_id,
                captured=False,
                message="PayPal capture did not complete successfully. The payment was not marked as captured.",
            )

        captured_amount = _extract_paypal_capture_amount(paypal_data)
        captured_currency = _extract_paypal_capture_currency(paypal_data)
        persisted = save_confirmed_payment_transaction(
            order_id=payload.order_id,
            amount=captured_amount,
            currency=captured_currency,
            description=(
                f"PayPal Sandbox payment captured for order {payload.order_id}"
                if captured_amount > 0
                else "PayPal Sandbox payment captured"
            ),
            payer_id=payload.payer_id,
            counterparty="PayPal Sandbox",
        )

        if persisted is None:
            return PaymentCaptureResponse(
                status="captured",
                order_id=payload.order_id,
                captured=True,
                message=(
                    "PayPal Sandbox payment was confirmed, but the local PostgreSQL transaction history could not be updated. "
                    "The payment itself is valid and complete."
                ),
            )

        return PaymentCaptureResponse(
            status="captured",
            order_id=payload.order_id,
            captured=True,
            message="PayPal Sandbox payment captured successfully and recorded in the transaction history.",
        )
    except HTTPException as exc:
        return PaymentCaptureResponse(
            status="failed",
            order_id=payload.order_id,
            captured=False,
            message=(
                "PayPal capture failed. This payment must not be treated as successful. "
                "Verify the Sandbox order ID and the PayPal credentials before retrying."
            ),
        )
    except Exception as exc:
        return PaymentCaptureResponse(
            status="failed",
            order_id=payload.order_id,
            captured=False,
            message=(
                "PayPal capture failed. This payment must not be treated as successful. "
                "Verify the Sandbox order ID and the PayPal credentials before retrying."
            ),
        )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
